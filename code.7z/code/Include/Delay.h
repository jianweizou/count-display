void Timer0_Init(void);

void Timer1_Delay10ms(unsigned long cnt);